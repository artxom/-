import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import { Send, Play, Terminal, CheckCircle, Loader2, DatabaseZap, Code, BookOpen } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface Proposal {
  sql: string;
  reasoning: string;
}

interface ToolExecution {
  id: string;
  name: string;
  args: string;
  result: string;
  status: 'running' | 'done' | 'error';
}

const AgentChatPage = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [executionResult, setExecutionResult] = useState('');
  
  // Streaming states
  const [currentAssistantMessage, setCurrentAssistantMessage] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [activeTools, setActiveTools] = useState<ToolExecution[]>([]);
  const [discoveredKnowledge, setDiscoveredKnowledge] = useState<string[]>([]);
  const [selectedKnowledge, setSelectedKnowledge] = useState<Set<number>>(new Set());
  
  const dialogRef = useRef<HTMLDialogElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, currentAssistantMessage, proposals, activeTools]);

  const handleSend = async () => {
    if (!prompt.trim() || loading) return;
    
    const userMsg: ChatMessage = { role: 'user', content: prompt };
    setMessages(prev => [...prev, userMsg]);
    setPrompt('');
    setLoading(true);
    setCurrentAssistantMessage('');
    setStatusMessage('连接中...');
    setActiveTools([]);
    setDiscoveredKnowledge([]);

    try {
      const response = await fetch('http://127.0.0.1:8000/api/agent/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMsg.content, history: history })
      });

      if (!response.body) throw new Error("ReadableStream not yet supported in this browser.");

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";
      
      let finalContent = "";
      let currentActiveTools: ToolExecution[] = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // keep the last partial line in buffer
        
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const data = JSON.parse(line);
            
            if (data.type === 'status') {
              setStatusMessage(data.message);
            } else if (data.type === 'content_chunk') {
              finalContent += data.chunk;
              setCurrentAssistantMessage(finalContent);
            } else if (data.type === 'tool_call') {
              const newTool: ToolExecution = {
                id: Math.random().toString(36).substring(7),
                name: data.name,
                args: data.arguments,
                result: '',
                status: 'running'
              };
              currentActiveTools = [...currentActiveTools, newTool];
              setActiveTools(currentActiveTools);
              setStatusMessage(`执行工具: ${data.name}`);
            } else if (data.type === 'tool_result') {
              currentActiveTools = currentActiveTools.map(t => 
                t.name === data.name && t.status === 'running' 
                  ? { ...t, result: data.result, status: data.result.includes('Error') ? 'error' : 'done' } 
                  : t
              );
              setActiveTools(currentActiveTools);
            } else if (data.type === 'finished') {
              setHistory(data.messages || []);
              if (data.proposals && data.proposals.length > 0) {
                setProposals(data.proposals);
              }
            } else if (data.type === 'knowledge_discovery') {
              setDiscoveredKnowledge(data.items);
              setSelectedKnowledge(new Set(data.items.map((_: any, i: number) => i)));
            } else if (data.type === 'error') {
               setStatusMessage(`错误: ${data.message}`);
               break;
            }
          } catch (e) {
             console.error("Error parsing stream JSON", line, e);
          }
        }
      }
      
      // Complete stream
      if (finalContent) {
        setMessages(prev => [...prev, { role: 'assistant', content: finalContent }]);
        setCurrentAssistantMessage('');
      }
      setStatusMessage('');
      setActiveTools([]);

    } catch (e: any) {
      setMessages(prev => [...prev, { role: 'system', content: `Error: ${e.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveKnowledge = async () => {
    const itemsToSave = discoveredKnowledge.filter((_, i) => selectedKnowledge.has(i));
    if (itemsToSave.length === 0) return;
    
    try {
      await axios.post('http://127.0.0.1:8000/api/knowledge/approve', { items: itemsToSave });
      setDiscoveredKnowledge([]);
      alert("知识已成功保存！");
    } catch (e) {
      console.error("Failed to save knowledge", e);
      alert("保存知识失败");
    }
  };

  const handleExecute = async (sql: string) => {
    try {
      setExecutionResult('执行中...');
      dialogRef.current?.showModal();
      
      const res = await axios.post('http://127.0.0.1:8000/api/db/execute', { sql });
      setExecutionResult(JSON.stringify(res.data, null, 2));
    } catch (e: any) {
      setExecutionResult(`执行失败: ${e.response?.data?.detail || e.message}`);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: '1rem' }} className="animate-fade-in">
      <div className="glass-panel" style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <h2>与 DeepSeek Agent 协作</h2>
        {messages.length === 0 && (
          <div style={{ textAlign: 'center', color: 'var(--text-muted)', marginTop: '2rem' }}>
            <Terminal size={48} style={{ opacity: 0.5, marginBottom: '1rem' }} />
            <p>告诉 Agent 你想怎样造数，例如：</p>
            <p>"帮我给 users 表随机插入 5 条测试数据"</p>
          </div>
        )}
        
        {messages.map((m, i) => (
          <div key={i} style={{ 
            alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
            backgroundColor: m.role === 'user' ? 'var(--primary)' : (m.role === 'system' ? 'var(--danger)' : 'rgba(255,255,255,0.05)'),
            padding: '1rem',
            borderRadius: '12px',
            maxWidth: '90%',
            overflowX: 'auto'
          }}>
            {m.role === 'user' ? (
              <p style={{ margin: 0, color: 'white', whiteSpace: 'pre-wrap' }}>{m.content}</p>
            ) : (
              <div className="markdown-body">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
              </div>
            )}
          </div>
        ))}
        
        {/* Streaming / Loading UI */}
        {(currentAssistantMessage || statusMessage || activeTools.length > 0) && (
           <div style={{ 
            alignSelf: 'flex-start',
            backgroundColor: 'rgba(255,255,255,0.05)',
            padding: '1rem',
            borderRadius: '12px',
            maxWidth: '90%'
          }}>
            {statusMessage && (
              <div style={{ color: 'var(--accent)', display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: currentAssistantMessage ? '1rem' : '0', fontSize: '0.9rem' }}>
                <Loader2 size={16} className="spinner" /> {statusMessage}
              </div>
            )}

            {activeTools.map((t, idx) => (
              <details key={t.id} style={{ marginBottom: '1rem', backgroundColor: 'rgba(0,0,0,0.2)', padding: '0.5rem 1rem', borderRadius: '8px' }}>
                <summary style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.5rem', color: t.status === 'error' ? 'var(--danger)' : 'var(--text-muted)' }}>
                  {t.name === 'execute_query' ? <DatabaseZap size={14}/> : <Code size={14}/>}
                  调用 {t.name}
                  {t.status === 'running' && <Loader2 size={12} className="spinner" />}
                </summary>
                <div style={{ marginTop: '0.5rem', fontSize: '0.85rem' }}>
                  <p style={{ color: 'var(--text-muted)' }}><strong>Args:</strong> {t.args}</p>
                  {t.result && (
                    <div style={{ marginTop: '0.5rem', maxHeight: '150px', overflowY: 'auto' }}>
                      <p style={{ color: 'var(--text-muted)' }}><strong>Result:</strong></p>
                      <pre style={{ backgroundColor: 'rgba(0,0,0,0.3)', padding: '0.5rem', borderRadius: '4px', color: '#a78bfa' }}>{t.result}</pre>
                    </div>
                  )}
                </div>
              </details>
            ))}

            {currentAssistantMessage && (
              <div className="markdown-body">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{currentAssistantMessage}</ReactMarkdown>
              </div>
            )}
          </div>
        )}
        
        {proposals.map((p, i) => (
          <div key={`prop-${i}`} style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', border: '1px solid var(--accent)', padding: '1rem', borderRadius: '12px', maxWidth: '80%' }}>
            <h4 style={{ color: 'var(--accent)', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <CheckCircle size={18} /> Agent 提出了修改提案
            </h4>
            <p style={{ fontSize: '0.9rem', marginBottom: '1rem' }}><strong>推理:</strong> {p.reasoning}</p>
            <pre style={{ backgroundColor: 'rgba(0,0,0,0.3)', padding: '1rem', borderRadius: '8px', overflowX: 'auto', color: '#e2e8f0', fontFamily: 'monospace' }}>
              {p.sql}
            </pre>
            <button className="mt-4" onClick={() => handleExecute(p.sql)}><Play size={16} /> 审核并执行 SQL</button>
          </div>
        ))}
        
        {discoveredKnowledge.length > 0 && (
          <div style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', border: '1px solid var(--primary)', padding: '1rem', borderRadius: '12px', maxWidth: '80%', alignSelf: 'center', width: '100%', marginTop: '1rem' }}>
            <h4 style={{ color: 'var(--primary)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <BookOpen size={18} /> 发现新知识！是否保存到长效记忆？
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem', marginBottom: '1.5rem' }}>
              {discoveredKnowledge.map((k, i) => (
                <label key={i} style={{ display: 'flex', gap: '0.5rem', cursor: 'pointer', fontSize: '0.95rem', color: 'var(--text)' }}>
                  <input 
                    type="checkbox" 
                    style={{ marginTop: '0.2rem' }}
                    checked={selectedKnowledge.has(i)}
                    onChange={(e) => {
                      const newSet = new Set(selectedKnowledge);
                      if (e.target.checked) newSet.add(i);
                      else newSet.delete(i);
                      setSelectedKnowledge(newSet);
                    }}
                  />
                  <span>{k}</span>
                </label>
              ))}
            </div>
            <div style={{ display: 'flex', gap: '1rem' }}>
              <button onClick={handleSaveKnowledge} style={{ flex: 1, display: 'flex', justifyContent: 'center', gap: '0.5rem' }}>
                <CheckCircle size={16} /> 保存选中的知识
              </button>
              <button className="secondary" onClick={() => setDiscoveredKnowledge([])} style={{ flex: 1 }}>
                忽略
              </button>
            </div>
          </div>
        )}
        
        <div ref={chatBottomRef} />
      </div>

      <div className="glass-panel" style={{ padding: '1rem', display: 'flex', gap: '1rem' }}>
        <input 
          style={{ margin: 0 }} 
          value={prompt} 
          onChange={e => setPrompt(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="描述您的造数需求..." 
          disabled={loading}
        />
        <button onClick={handleSend} disabled={loading}>
          {loading ? <Loader2 size={18} className="spinner" /> : <Send size={18} />} 发送
        </button>
      </div>

      <dialog ref={dialogRef}>
        <h2>执行结果</h2>
        <pre style={{ backgroundColor: 'rgba(0,0,0,0.5)', padding: '1rem', borderRadius: '8px', overflowX: 'auto', maxHeight: '300px' }}>
          {executionResult}
        </pre>
        <form method="dialog" className="mt-4">
          <button className="secondary">关闭</button>
        </form>
      </dialog>
      
      <style>{`
        @keyframes spin { 100% { transform: rotate(360deg); } }
        .spinner { animation: spin 1s linear infinite; }
      `}</style>
    </div>
  );
};

export default AgentChatPage;
