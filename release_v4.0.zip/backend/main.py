from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
import json
import os
from database import db_manager, DBConfig
from agent import agent_config, run_agent_loop_stream
from memory import memory_manager
from analytics import analytics_manager
import uvicorn

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AppConfig(BaseModel):
    db_config: DBConfig
    api_key: str
    base_url: str = "https://api.deepseek.com/v1"
    model: str = "deepseek-v4-pro"

CONFIG_FILE = "app_config.json"

def load_saved_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                data = json.load(f)
                return AppConfig(**data)
        except Exception:
            pass
    return None

def save_config_to_disk(config: AppConfig):
    with open(CONFIG_FILE, 'w') as f:
        f.write(config.model_dump_json(indent=2))

saved_config = load_saved_config()
if saved_config:
    db_manager.connect(saved_config.db_config)
    agent_config.api_key = saved_config.api_key
    agent_config.base_url = saved_config.base_url
    agent_config.model = saved_config.model

@app.get("/api/config")
def get_config():
    if saved_config:
        return saved_config.model_dump()
    return {}

@app.post("/api/config")
def set_config(config: AppConfig):
    success, msg = db_manager.connect(config.db_config)
    if not success:
        raise HTTPException(status_code=400, detail=msg)
    
    agent_config.api_key = config.api_key
    agent_config.base_url = config.base_url
    agent_config.model = config.model
    
    save_config_to_disk(config)
    global saved_config
    saved_config = config
    
    return {"status": "success", "message": "Configuration applied successfully."}

class ChatRequest(BaseModel):
    prompt: str
    history: list = []
    field_constraints: dict = {}

@app.post("/api/agent/chat")
def agent_chat(req: ChatRequest):
    return StreamingResponse(
        run_agent_loop_stream(req.prompt, req.history, req.field_constraints),
        media_type="application/x-ndjson"
    )

class ExecuteRequest(BaseModel):
    sql: str

@app.post("/api/db/execute")
def execute_sql(req: ExecuteRequest):
    try:
        res = db_manager.execute_query(req.sql)
        return {"status": "success", "data": res}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/db/schema-tree")
def get_schema_tree():
    try:
        return {"status": "success", "data": db_manager.get_schema_tree()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/db/schema/{schema_name}/{table_name}/fields")
def get_table_fields(schema_name: str, table_name: str):
    try:
        schema_data = db_manager.get_table_schema(table_name, schema=schema_name)
        if not schema_data:
            raise HTTPException(status_code=404, detail="Table not found")
        return {"status": "success", "data": schema_data["columns"]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class ApproveKnowledgeRequest(BaseModel):
    items: list[str]

@app.post("/api/knowledge/approve")
def approve_knowledge(req: ApproveKnowledgeRequest):
    try:
        memory_manager.add_knowledge(req.items)
        return {"status": "success", "message": f"Added {len(req.items)} knowledge items."}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/knowledge")
def get_knowledge():
    try:
        return {"status": "success", "data": memory_manager.get_all_knowledge()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class UpdateKnowledgeRequest(BaseModel):
    content: str

@app.put("/api/knowledge/{knowledge_id}")
def update_knowledge(knowledge_id: int, req: UpdateKnowledgeRequest):
    try:
        memory_manager.update_knowledge(knowledge_id, req.content)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/knowledge/{knowledge_id}")
def delete_knowledge(knowledge_id: int):
    try:
        memory_manager.delete_knowledge(knowledge_id)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/analytics")
def get_analytics():
    try:
        return {
            "status": "success",
            "data": {
                "daily": analytics_manager.get_daily_stats(),
                "today": analytics_manager.get_today_hourly_stats()
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
# Serve static files in production
import os
frontend_dist = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend", "dist")
if os.path.exists(frontend_dist):
    app.mount("/assets", StaticFiles(directory=os.path.join(frontend_dist, "assets")), name="assets")
    
    @app.get("/{full_path:path}")
    def serve_frontend(full_path: str):
        return FileResponse(os.path.join(frontend_dist, "index.html"))

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
